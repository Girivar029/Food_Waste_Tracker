export class NotificationService {
  // Ask the user for permission to show notifications
  static async requestPermission(): Promise<boolean> {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      console.warn('This browser does not support notifications');
      return false;
    }

    // Already decided
    if (Notification.permission === 'granted') return true;
    if (Notification.permission === 'denied') return false;

    // Ask now
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }

  // Show a notification if permitted
  static showNotification(title: string, options?: NotificationOptions): Notification | undefined {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      console.warn('Notifications are not supported in this environment');
      return;
    }
    if (Notification.permission !== 'granted') {
      // Optionally call requestPermission() here if desired
      return;
    }

    const notification = new Notification(title, {
      icon: '/favicon.ico',
      badge: '/favicon.ico',
      ...options,
    });

    // Auto close after 5 seconds
    setTimeout(() => {
      notification.close();
    }, 5000);

    return notification;
  }

  // Schedule two random notifications per day between 9 AM and 9 PM
  static scheduleDailyReminders(): void {
    // Helper to schedule a notification at a given local time (HH:mm)
    const scheduleAt = (hours: number, minutes: number) => {
      const now = new Date();
      const scheduledTime = new Date();
      scheduledTime.setHours(hours, minutes, 0, 0);

      // If the time today already passed, schedule for tomorrow
      if (scheduledTime.getTime() <= now.getTime()) {
        scheduledTime.setDate(scheduledTime.getDate() + 1);
      }

      const timeUntilNotification = scheduledTime.getTime() - now.getTime();

      setTimeout(() => {
        NotificationService.showNotification('Food Waste Tracker', {
          body: "Don't forget to log your food waste today! 🥬",
          tag: 'daily-reminder',
        });

        // Schedule the same time for the next day (24h)
        setTimeout(
          () => scheduleAt(hours, minutes),
          24 * 60 * 60 * 1000
        );
      }, timeUntilNotification);
    };

    // Random times: one between 9:00–14:59, one between 15:00–20:59
    const time1 = {
      hours: 9 + Math.floor(Math.random() * 6), // 9..14
      minutes: Math.floor(Math.random() * 60),
    };
    const time2 = {
      hours: 15 + Math.floor(Math.random() * 6), // 15..20
      minutes: Math.floor(Math.random() * 60),
    };

    scheduleAt(time1.hours, time1.minutes);
    scheduleAt(time2.hours, time2.minutes);
  }
}
