"use client";

import { useState } from "react";
import { NotificationService } from "../utils/notifications";

type FormData = { 
  rice: number; 
  vegetables: number; 
  proteins: number; 
  dairy: number; 
  leftovers: number; 
};

type Props = { 
  onSave?: (data: FormData & { timestamp: string }) => void; 
};

const PRICE_PER_KG = { 
  rice: 50, 
  vegetables: 20, 
  proteins: 120, 
  dairy: 60, 
  leftovers: 30 
};

const categoryData = {
  rice: { icon: "🍚", label: "Rice & Grains", color: "from-yellow-500 to-orange-500" },
  vegetables: { icon: "🥦", label: "Vegetables", color: "from-green-500 to-emerald-500" },
  proteins: { icon: "🍖", label: "Proteins", color: "from-red-500 to-pink-500" },
  dairy: { icon: "🥛", label: "Dairy Products", color: "from-blue-500 to-cyan-500" },
  leftovers: { icon: "🍽️", label: "Leftovers", color: "from-purple-500 to-indigo-500" },
};

export default function WasteInputForm({ onSave }: Props) {
  const [formData, setFormData] = useState<FormData>({
    rice: 0,
    vegetables: 0,
    proteins: 0,
    dairy: 0,
    leftovers: 0,
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const numValue = Math.max(0, Number(value) || 0);
    setFormData({ ...formData, [name]: numValue });
    setSubmitted(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Simulate processing
    await new Promise(resolve => setTimeout(resolve, 1000));

    const timestamp = new Date().toISOString();
    setSubmitted(true);
    setLoading(false);

    if (onSave) {
      onSave({ ...formData, timestamp });
    }

    // Show success notification
    NotificationService.showNotification('Waste Logged Successfully!', {
      body: `Total waste: ${Object.values(formData).reduce((a, b) => a + b, 0)}g recorded`,
      icon: '/favicon.ico',
    });

    // Reset form after 3 seconds
    setTimeout(() => {
      setFormData({ rice: 0, vegetables: 0, proteins: 0, dairy: 0, leftovers: 0 });
      setSubmitted(false);
    }, 3000);
  };

  const totalWeight = Object.values(formData).reduce((a, b) => a + b, 0);
  const totalCost = Object.entries(formData).reduce((total, [key, grams]) => {
    const kg = Number(grams) / 1000;
    return total + (PRICE_PER_KG[key as keyof typeof PRICE_PER_KG] || 0) * kg;
  }, 0);

  return (
    <div className="max-w-2xl mx-auto">
      <div className="card p-8">
        <h2 className="text-3xl font-bold mb-6 text-center bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
          Log Your Daily Waste
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {Object.entries(formData).map(([key, value]) => {
              const category = categoryData[key as keyof typeof categoryData];
              return (
                <div key={key} className="space-y-2">
                  <label 
                    htmlFor={key} 
                    className="flex items-center gap-3 text-lg font-medium text-gray-200 cursor-pointer"
                  >
                    <div className={`p-2 rounded-lg bg-gradient-to-r ${category.color} text-white`}>
                      <span className="text-xl">{category.icon}</span>
                    </div>
                    <span>{category.label}</span>
                  </label>
                  <div className="relative">
                    <input
                      id={key}
                      type="number"
                      min={0}
                      max={5000}
                      name={key}
                      value={value || ''}
                      onChange={handleChange}
                      placeholder="0"
                      className="input-field pr-16"
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
                      grams
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {totalWeight > 0 && (
            <div className="card p-4 bg-gradient-to-r from-gray-800 to-gray-700 border-green-500/30">
              <div className="flex justify-between items-center text-sm text-gray-300">
                <span>Total Weight: <span className="font-semibold text-green-400">{totalWeight}g</span></span>
                <span>Est. Value: <span className="font-semibold text-red-400">₹{totalCost.toFixed(2)}</span></span>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading || totalWeight === 0}
            className={`w-full btn-primary py-4 text-lg font-bold ${
              loading ? 'opacity-75 cursor-not-allowed' : ''
            } ${totalWeight === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {loading ? (
              <span className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                Processing...
              </span>
            ) : (
              `Save Waste Data (${totalWeight}g)`
            )}
          </button>
        </form>

        {submitted && (
          <div className="mt-6 card p-4 bg-gradient-to-r from-green-700/30 to-emerald-700/30 border-green-500/50">
            <div className="flex items-center justify-center space-x-2">
              <span className="text-2xl">✅</span>
              <div>
                <p className="font-semibold text-green-300">Successfully Logged!</p>
                <p className="text-sm text-green-400">
                  {totalWeight}g waste worth ₹{totalCost.toFixed(2)} recorded
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
