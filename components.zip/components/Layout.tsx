"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import React, { ReactNode, useEffect } from "react";
import { NotificationService } from "../utils/notifications";

type LayoutProps = {
  children: ReactNode;
  title?: string;
};

export default function Layout({ children, title }: LayoutProps) {
  const pathname = usePathname();

  useEffect(() => {
    // Request notification permission on app load
    NotificationService.requestPermission().then((granted) => {
      if (granted) {
        NotificationService.scheduleDailyReminders();
      }
    });
  }, []);

  const navLinks = [
    { href: "/history", label: "History", icon: "📊" },
    { href: "/summary", label: "Summary", icon: "📈" },
    { href: "/tips", label: "Tips", icon: "💡" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-gray-100">
      <header className="bg-gray-800/80 backdrop-blur-sm shadow-xl border-b border-gray-700 sticky top-0 z-50">
        <nav className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <Link href="/" className="flex items-center space-x-2 text-green-400 hover:text-green-300 transition-colors">
              <span className="text-3xl">🥬</span>
              <span className="text-xl font-bold">Food Waste Tracker</span>
            </Link>
            
            <div className="flex space-x-6">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`flex items-center space-x-1 px-3 py-2 rounded-lg transition-colors ${
                    pathname === link.href
                      ? 'bg-green-600 text-white'
                      : 'text-gray-300 hover:text-green-400 hover:bg-gray-700'
                  }`}
                >
                  <span className="text-lg">{link.icon}</span>
                  <span className="font-medium">{link.label}</span>
                </Link>
              ))}
            </div>
          </div>
        </nav>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10">
        {title && (
          <div className="text-center mb-10">
            <h1 className="text-5xl font-extrabold mb-4 bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
              {title}
            </h1>
            <div className="w-24 h-1 bg-gradient-to-r from-green-400 to-emerald-500 mx-auto rounded"></div>
          </div>
        )}
        {children}
      </main>

      <footer className="bg-gray-800/80 backdrop-blur-sm text-gray-400 text-center py-6 border-t border-gray-700">
        <p>© 2025 Food Waste Tracker. Built for a sustainable future. 🌱</p>
      </footer>
    </div>
  );
}
